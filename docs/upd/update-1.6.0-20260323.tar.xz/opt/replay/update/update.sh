#!/usr/bin/env bash
set -euo pipefail

export LC_ALL=C
export TZ=UTC
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

###############################################################################
# RePlayOS OTA updater
#
# Expected package layout:
#   update.tar.xz
#     └── opt/replay/update/local-upd-manifest.json
#     └── ...
#
# This script:
#   1. checks if an update is pending
#   2. extracts the OTA into a staging dir
#   3. validates manifest and platform
#   4. runs APT actions from manifest
#   5. overlays rootfs into /
#   6. updates local manifest
#   7. marks success
#
# Notes:
# - Keeps things simple, no rollback
# - APT manages distro packages
# - rsync overlays custom files
###############################################################################

UPDATE_DIR="/opt/replay/update"
PENDING_FLAG="$UPDATE_DIR/pending"
OTA_FILE="$UPDATE_DIR/update.tar.xz"
STAGING_DIR="/run/replay-update"
LOG_FILE="$UPDATE_DIR/update.log"

LOCAL_MANIFEST="$UPDATE_DIR/local-upd-manifest.json"
STAGED_MANIFEST="$STAGING_DIR/$UPDATE_DIR/local-upd-manifest.json"

RSYNC_EXCLUDES=(
  "/dev/*"
  "/proc/*"
  "/sys/*"
  "/tmp/*"
  "/run/*"
  "/mnt/*"
  "/media/*"
  "/lost+found"
)

APT_GET_COMMON_OPTS=(
  -o Dpkg::Use-Pty=0
  -o DPkg::Lock::Timeout=120
  -o Dpkg::Options::=--force-confdef
  -o Dpkg::Options::=--force-confold
)

log() {
  printf '[%s] %s\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$LOG_FILE"
}

fail() {
  log "ERROR: $*"
  exit 1
}

show_log_tail() {
  if [[ -f "$LOG_FILE" ]]; then
    {
      printf '%s\n' "--- Last 40 lines of $LOG_FILE ---"
      tail -n 40 "$LOG_FILE"
      printf '%s\n' "--- End of log tail ---"
    } >&2
  fi
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"
}

cleanup() {
  rm -rf "$STAGING_DIR"
}
trap cleanup EXIT

get_current_platform() {
  # Map supported Raspberry Pi variants onto the existing OTA buckets.
  local model=""
  if [[ -r /proc/device-tree/model ]]; then
    model="$(tr -d '\0' < /proc/device-tree/model)"
  fi

  case "$model" in
    *"Raspberry Pi Zero 2"*|*"Raspberry Pi 3"*) echo "rpi3" ;;
    *"Raspberry Pi Compute Module 4"*|*"Raspberry Pi 400"*|*"Raspberry Pi 4"*) echo "rpi4" ;;
    *"Raspberry Pi Compute Module 5"*|*"Raspberry Pi 500"*|*"Raspberry Pi 5"*) echo "rpi5" ;;
    *) echo "unknown" ;;
  esac
}

manifest_get() {
  local jq_expr="$1"
  jq -r "$jq_expr" "$STAGED_MANIFEST"
}

manifest_bool() {
  local jq_expr="$1"
  jq -e "$jq_expr" "$STAGED_MANIFEST" >/dev/null 2>&1
}

validate_manifest() {
  log "Validating manifest"

  [[ -f "$STAGED_MANIFEST" ]] || fail "Manifest not found in OTA: $STAGED_MANIFEST"

  jq -e '
    (.product | type == "string") and
    (.version | type == "string") and
    (.build | type == "string") and
    (.platforms | type == "array") and
    (all(.platforms[]; type == "string")) and
    (.requires_reboot | type == "boolean") and
    (.schema | type == "number") and
    (
      (has("apt") | not) or
      (
        (.apt | type == "object") and
        (.apt.update | type == "boolean") and
        (.apt.install | type == "array") and
        (.apt.remove | type == "array") and
        (.apt.full_upgrade | type == "boolean") and
        (all(.apt.install[]?; type == "string")) and
        (all(.apt.remove[]?; type == "string"))
      )
    )
  ' "$STAGED_MANIFEST" >/dev/null || fail "Manifest validation failed"
}

check_platform() {
  local current_platform
  current_platform="$(get_current_platform)"

  log "Detected platform: $current_platform"

  jq -e --arg p "$current_platform" '.platforms | index($p) != null' \
    "$STAGED_MANIFEST" >/dev/null || {
      fail "OTA does not support this platform: $current_platform"
    }
}

check_version() {
  local new_version new_build current_version current_build

  new_version="$(manifest_get '.version')"
  new_build="$(manifest_get '.build')"

  if [[ -f "$LOCAL_MANIFEST" ]]; then
    current_version="$(jq -r '.version // empty' "$LOCAL_MANIFEST")"
    current_build="$(jq -r '.build // empty' "$LOCAL_MANIFEST")"
  else
    current_version=""
    current_build=""
  fi

  log "Installed version: ${current_version:-<none>} build ${current_build:-<none>}"
  log "OTA version: $new_version build $new_build"

  # Optional skip if exact same version+build
  if [[ -n "$current_version" && -n "$current_build" ]] && \
     [[ "$current_version" == "$new_version" ]] && \
     [[ "$current_build" == "$new_build" ]]; then
    fail "Same version/build already installed"
  fi
}

extract_ota() {
  log "Extracting OTA package: $OTA_FILE"

  [[ -f "$OTA_FILE" ]] || fail "OTA file not found: $OTA_FILE"

  rm -rf "$STAGING_DIR"
  mkdir -p "$STAGING_DIR"

  tar -xJf "$OTA_FILE" -C "$STAGING_DIR"
}

run_preupdate() {
  local script="$STAGING_DIR/$UPDATE_DIR/preupdate.sh"
  if [[ -f "$script" ]]; then
    chmod 755 "$script"
    log "Running preupdate.sh"
    "$script" >>"$LOG_FILE" 2>&1
  fi
}

run_postupdate() {
  local script="$STAGING_DIR/$UPDATE_DIR/postupdate.sh"
  if [[ -f "$script" ]]; then
    chmod 755 "$script"
    log "Running postupdate.sh"
    "$script" >>"$LOG_FILE" 2>&1
  fi
}

run_apt_command() {
  local description="$1"
  shift

  log "$description"
  if ! apt-get "${APT_GET_COMMON_OPTS[@]}" "$@" >>"$LOG_FILE" 2>&1; then
    show_log_tail
    fail "APT command failed: apt-get $*"
  fi
}

apt_update_if_needed() {
  if manifest_bool '.apt.update == true'; then
    run_apt_command "Running apt-get update" update
  else
    log "APT update skipped"
  fi
}

apt_full_upgrade_if_needed() {
  if manifest_bool '.apt.full_upgrade == true'; then
    run_apt_command "Running apt-get full-upgrade" -y full-upgrade
  else
    log "APT full-upgrade skipped"
  fi
}

apt_install_if_needed() {
  mapfile -t pkgs < <(jq -r '.apt.install[]?' "$STAGED_MANIFEST")

  if [[ "${#pkgs[@]}" -eq 0 ]]; then
    log "No APT packages to install"
    return
  fi

  run_apt_command "Installing APT packages: ${pkgs[*]}" -y install "${pkgs[@]}"
}

apt_remove_if_needed() {
  mapfile -t pkgs < <(jq -r '.apt.remove[]?' "$STAGED_MANIFEST")

  if [[ "${#pkgs[@]}" -eq 0 ]]; then
    log "No APT packages to remove"
    return
  fi

  run_apt_command "Removing APT packages: ${pkgs[*]}" -y remove "${pkgs[@]}"
}

overlay_rootfs() {
  log "Overlaying staged filesystem into /"

  local rsync_args=(
    -aHAX
    --numeric-ids
    --info=stats1,progress2
  )

  local ex
  for ex in "${RSYNC_EXCLUDES[@]}"; do
    rsync_args+=(--exclude="$ex")
  done

  # Keep the live manifest unchanged until the update is fully successful.
  rsync_args+=(--exclude="$LOCAL_MANIFEST")

  rsync "${rsync_args[@]}" "$STAGING_DIR"/ / >>"$LOG_FILE" 2>&1
}

refresh_system_state() {
  log "Refreshing system state"

  if command -v ldconfig >/dev/null 2>&1; then
    ldconfig >>"$LOG_FILE" 2>&1 || true
  fi

  if command -v systemctl >/dev/null 2>&1; then
    systemctl daemon-reload >>"$LOG_FILE" 2>&1 || true
  fi
}

mark_success() {
  mkdir -p "$UPDATE_DIR"

  if [[ -f "$LOCAL_MANIFEST" ]]; then
    cp -f "$LOCAL_MANIFEST" "$UPDATE_DIR/update-manifest.prev.json" || true
  fi

  cp -f "$STAGED_MANIFEST" "$LOCAL_MANIFEST"
  rm -f "$PENDING_FLAG"
  rm -f "$OTA_FILE"

  log "Update applied successfully"
}

main() {
  [[ -f "$PENDING_FLAG" ]] || exit 0
  [[ "$(id -u)" -eq 0 ]] || fail "This script must run as root"

  mkdir -p "$UPDATE_DIR"
  : > "$LOG_FILE"

  require_cmd jq
  require_cmd tar
  require_cmd rsync
  require_cmd apt-get

  log "Starting RePlayOS OTA update"

  extract_ota
  validate_manifest
  check_platform
  check_version

  run_preupdate

  # System packages first, then overlay custom files
  apt_update_if_needed
  apt_full_upgrade_if_needed
  apt_install_if_needed
  apt_remove_if_needed

  overlay_rootfs
  refresh_system_state
  run_postupdate
  mark_success

  if manifest_bool '.requires_reboot == true'; then
    log "Manifest requests reboot"
  else
    log "Manifest does not require reboot"
  fi
}

main "$@"
